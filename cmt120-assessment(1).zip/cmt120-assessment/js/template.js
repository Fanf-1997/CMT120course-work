// Exercise 1
function reduceFraction(num, den) {
    return undefined;
}

// Exercise 2
function isMagicDate(day, month, year) {
    return undefined;
}

// Exercise 3
function sublist(l) {
    return undefined;
}

// Exercise 4
function pigLatin(word) {
    return undefined
}

// Exercise 5
function morseCode(message) {
    return undefined
}

// Exercise 6
function int2Text(num) {
    return undefined
}

// Exercise 7
function missingComment(filename) {
    return undefined
}

// Exercise 8
function consistentLineLength(filename, length) {
    return undefined
}

// Exercise 9
function knight(start, end, moves) {
    return undefined
}

// Exercise 10
function warOfSpecies(environment) {
    return undefined
}

module.exports = {
    reduceFraction: reduceFraction,
    isMagicDate: isMagicDate,
    sublist: sublist,
    pigLatin: pigLatin,
    morseCode: morseCode,
    int2Text: int2Text,
    missingComment: missingComment,
    consistentLineLength: consistentLineLength,
    knight: knight,
    warOfSpecies: warOfSpecies
}