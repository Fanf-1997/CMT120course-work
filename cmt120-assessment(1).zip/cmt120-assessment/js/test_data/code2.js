// Commenting this function
function function1(value) {
    console.log(value + 1)
}

// Commenting this other function
function function2(obj) {
    return function1(obj.value) // 10
}
