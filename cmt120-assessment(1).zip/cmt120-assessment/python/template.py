# Exercise 1
def reduceFraction(num, den):
    return None


# Exercise 2
def isMagicDate(day, month, year):
    return None


# Exercise 3
def sublist(l):
    return None


# Exercise 4
def pigLatin(word):
    return None


# Exercise 5
def morseCode(message):
    return None


# Exercise 6
def int2Text(num):
    return None


# Exercise 7
def missingComment(filename):
    return None


# Exercise 8
def consistentLineLength(filename, length):
    return None


# Exercise 9
def knight(start, end, moves):
    return None


# Exercise 10
def warOfSpecies(environment):
    return None
